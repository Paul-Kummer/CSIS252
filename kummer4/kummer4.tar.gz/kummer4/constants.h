// File: constants.h
// Name: Paul Kummer
// Class: CSIS 252
// Program: prog4
// Modified: 10/12/20

#pragma once

const int arraySize = 79; // determines the maximum array size for struct array