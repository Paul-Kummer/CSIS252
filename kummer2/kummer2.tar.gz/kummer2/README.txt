File: check2.cpp
Name: Paul Kummer
Class: CSIS 252
Program: assignment 2
Date: 9/25/20

[Description]
Check2.cpp will take two user inputted measurments from a prompt and notify the user if the two measurments
are able to convert between each other. The program determines unit compatibilities by takeing a command line
argument that is a .txt file containing two comma seperated strings per line. On each line, the first string
before the comma will be the unit name. The string after the comma will be the unit type. When both units have
the same unit type, the program will say they are compatible. If there isn't a match, it will say they are 
incompatible

[Challenges]
While making this program, there are ways of checking arrays in other languages that are simpiler to write
than the way I did it in this program. I think if I knew more about the methods and functions of c++ I could
reduce the number of lines of code. Also, I don't like the way output formatting is done in c++. It's harder
to make things look nice.