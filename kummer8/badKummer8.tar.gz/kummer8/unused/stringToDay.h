#pragma once

//take in a string and output a day or "Unknown"
void stringToDay(std::string&);