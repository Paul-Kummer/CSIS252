// File: constants.h
// Name: Paul Kummer
// Class: CSIS 252
// Program: prog8
// Modified: 11/09/20

#pragma once

int maxMailboxSize = 50;