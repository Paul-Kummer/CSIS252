Kai Yodoya
10/23/20
README.txt
Assignment 5
CSIS 252


file		function		description
--------------------------------------------------------------
main.cpp	main			main function. This is the test
					driver of the Foot class
meter.cpp	Foot methods, etc.	implementation of the Foot class
meter.h		Foot			Foot class declaration/specification











