// File: prototypes.h
// Name: Paul Kummer
// Class: CSIS 252
// Program: prog9
// Modified: 11/15/20

#pragma once
#include <string>

// declare functions to be used by the route insertion operator
void splitStrByNum (std::string*, std::string);
int checkGrade (std::string);
