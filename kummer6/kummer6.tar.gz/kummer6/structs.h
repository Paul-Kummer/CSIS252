// File: structs.h
// Name: Paul Kummer
// Class: CSIS 252
// Program: prog4
// Modified: 10/12/20

#pragma once
#include <string>

// make an object that has a unitName and unitType
struct unitMeasurement
{
	std::string name;
	std::string type;
};