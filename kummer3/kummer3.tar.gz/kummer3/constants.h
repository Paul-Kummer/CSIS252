// File: constants.h
// Name: Paul Kummer
// Class: CSIS 252
// Program: prog3
// Modified: 9/29/20

#pragma once

const int arraySize = 50; // determines the maximum array size for unit names and unit types